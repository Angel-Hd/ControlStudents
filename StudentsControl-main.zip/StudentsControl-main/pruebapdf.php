<!DOCTYPE html>
    <html>
        <head>
            <meta htto-equiv="Content-Type" content="text/html" charset="UTF-8">
            <style>
            body{
                font-size: 16px;color: black;
            }
            table {
                table-layout: fixed;
                width: 100%;
                border-collapse: collapse;
                border: 3px solid purple;
            }

            thead th:nth-child(1) {
                width: 30%;
            }

            thead th:nth-child(2) {
                width: 20%;
            }

            thead th:nth-child(3) {
                width: 15%;
            }

            thead th:nth-child(4) {
                width: 35%;
            }

            th, td {
                padding: 30px;
            }

            </style>
            <title>Recibo: ".$nombre."</title>
        </head>
        <body>            
        <table summary='Recibo'>
            <tbody>
                <tr>
                <td colspan='2'>Ingeniería Matemática</td>
                <td colspan='2' ALIGN='right' >Fecha: ".$fecha." a las ".$hora."</td>
                </tr>
                <tr>
                <td >Id Alumno: ".$idalumno."</td>
                <td colspan='3'>Nombre: ".$nombre." ".$apellido."</td>
                </tr>
                <tr>
                <td colspan='4'>Recibí la cantidad de $".$cantidad." (MXN) con el concepto de: ".$concepto." de el alumno(a) ".$nombre." ".$apellido." con domicilio ".$direccion." y teléfono ".$telefono." a razón del tutor ".$tutor."</td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                <td colspan='3' ALIGN='right'>Firma</td>
                <td>Restan: ".$restan."</td>
                </tr>
            </tfoot>
            </table>
            <p></p>
            <a></a>
            <h1></h1>
            <table summary='Recibo'>
            <tbody>
                <tr>
                <td colspan='2'>Ingeniería Matemática</td>
                <td colspan='2' ALIGN='right' >Fecha: ".$fecha." a las ".$hora."</td>
                </tr>
                <tr>
                <td >Id Alumno: ".$idalumno."</td>
                <td colspan='3'>Nombre: ".$nombre." ".$apellido."</td>
                </tr>
                <tr>
                <td colspan='4'>Recibí la cantidad de $".$cantidad." (MXN) con el concepto de: ".$concepto." de el alumno(a) ".$nombre." ".$apellido." con domicilio ".$direccion." y teléfono ".$telefono." a razón del tutor ".$tutor."</td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                <td colspan='3' ALIGN='right'>Firma</td>
                <td>Restan: ".$restan."</td>
                </tr>
            </tfoot>
            </table>
        </body>
    </html>