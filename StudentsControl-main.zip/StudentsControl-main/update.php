<!DOCTYPE html>
<html lang="en">
    <head>  
    <meta htto-equiv="Content-Type" content="text/html" charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registros</title>
    <link href="https://fonts.googleapis.com/css2?family=Bitter:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="css/main.css">
    </head>
    <body>
        <!--Navrbar-->
        <nav class="navbar navbar-expand-sm navbar-dark bg-dark" id="navbar">
            <div class="container-fluid">
            <a class="navbar-brand" href="http://localhost/Control/menu.php">
                    <img src="img/logo3.png" alt="" width="200">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="http://localhost/Control/menu.php">Alumnos</a></li>
                        <li class="nav-item"><a class="nav-link" href="http://localhost/Control/update.php">Registro</a></li>
                        <li class="nav-item"><a class="nav-link" href="http://localhost/Control/consulta.php">Consulta</a></li>
                        <li class="nav-item"><a class="nav-link" href="http://localhost/Control/pagos.php">Pagos</a></li>
                        <li class="nav-item"><a class="nav-link" href="http://localhost/Control/">Sign out</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!--Select para mostrar-->

        <?php

        ?>

        <!--Carrousel-->
        <h2></h2>
        <div class="col-md-12 ml-md-auto">
            <h2>Alta de alumnos</h2>
            <p>Registros actuales a: <?php  echo(date("j")."/".date("F")."/".date("Y")); ?></p>   
        </div>
        <!--Form-->
        <div class="col-md-12 ml-md-auto">
            <form class="col-12" action="guardar.php" method="POST">
                <div class="form-group">
                    <label for="nombre">Nombres</label>
                    <input type="text" class="form-control" placeholder="Nombres" name=nombre>
                </div>
                <div class="form-group">
                    <label for="apellido">Apellidos</label>
                    <input type="text" class="form-control" placeholder="Apellidos" name=apellido>
                </div>
                <div class="form-group">
                    <label for="telefono">Teléfono</label>
                    <input type="tel" class="form-control" placeholder="8181555555" name=telefono>
                </div>
                <div class="form-group">
                    <label for="direccion">Dirección</label>
                    <input type="text" class="form-control" placeholder="Av. Street #555" name=direccion>
                </div>
                <div class="form-group">
                    <label for="email">Email address</label>
                    <input type="email" class="form-control" placeholder="name@example.com" name=email>
                </div>
                <div class="form-group">
                    <label for="tutor">Tutor</label>
                    <input type="text" class="form-control" placeholder="nombre-apellido" name=tutor>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
        <!--script-->    
        <script src="js/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
    </body>
</html>
