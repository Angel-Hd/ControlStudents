<?php 
    include('conn.php');
    $sql = "DELETE FROM registro WHERE id=".$_POST['eliminar'];
    if (mysqli_query($conn, $sql)) {
        header("Location: http://localhost/Control/consulta.php");       
    }
?>