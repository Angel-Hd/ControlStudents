<?php 
            include('conn.php');
            $ver=0;
            $consulta = "SELECT * FROM login";
            $resultado = mysqli_query( $conn, $consulta );
            while ($columna = mysqli_fetch_array( $resultado ))
            {
                if($columna['usuario']==$_POST['username'] &&  $columna['contra']==$_POST['password']){
                    $ver=$ver+1;
                }
            }
            if($ver==0){
                
            }else{
                header("Status: 301 Moved Permanently");
                header("Location: http://localhost/Control/menu.php");
                exit;     
            }
        ?>