<?php 
    include('conn.php');
    $consulta = "SELECT * FROM registro WHERE id=".$_POST['id'];
    $resultado = mysqli_query( $conn, $consulta );

    $idalumno = $_POST['id'];
    $concepto = $_POST['concepto'];
    $cantidad = $_POST['cantidad'];
    $fecha = date("j")."/".date("F")."/".date("Y");
    
    while ($columna = mysqli_fetch_array( $resultado))
    {
        $nombre = $columna['1'];
        $apellido = $columna['2'];
        $direccion = $columna['4'];
        $telefono = $columna['3'];
        $tutor = $columna['6'];
    }
    $restan = $_POST['restan']; //pendiente
    
    // Jalamos las librerias de dompdf
    require_once 'dompdf/autoload.inc.php';
    use Dompdf\Dompdf;
    $html="
    <!DOCTYPE html>
    <html>
        <head>
            <meta htto-equiv='Content-Type' content='text/html' charset='UTF-8'>
            <style>
            body{
                font-size: 16px;color: black;
            }
            table {
                table-layout: fixed;
                width: 100%;
                border-collapse: collapse;
                border: 3px solid purple;
            }

            thead th:nth-child(1) {
                width: 30%;
            }

            thead th:nth-child(2) {
                width: 20%;
            }

            thead th:nth-child(3) {
                width: 15%;
            }

            thead th:nth-child(4) {
                width: 35%;
            }

            th, td {
                padding: 30px;
            }

            </style>
            <title>Recibo: ".$nombre."</title>
        </head>
        <body>            
            <table summary='Recibo'>
            <tbody>
                <tr>
                <td colspan='2'>Ingeniería Matemática</td>
                <td colspan='2' ALIGN='right' >Fecha: ".$fecha."</td>
                </tr>
                <tr>
                <td >Id Alumno: ".$idalumno." B</td>
                <td colspan='3'>Nombre: ".$nombre." ".$apellido."</td>
                </tr>
                <tr>
                <td colspan='4'>Recibí la cantidad de $".$cantidad." (MXN) con el concepto de: ".$concepto." de el alumno(a) ".$nombre." ".$apellido." con domicilio ".$direccion." y teléfono ".$telefono." a razón del tutor ".$tutor."</td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                <td colspan='3' ALIGN='right'>Firma</td>
                <td>Restan: $".$restan." (MXN)</td>
                </tr>
            </tfoot>
            </table>
            <p></p>
            <a></a>
            <h1></h1>
            <table summary='Recibo'>
            <tbody>
                <tr>
                <td colspan='2'>Ingeniería Matemática</td>
                <td colspan='2' ALIGN='right' >Fecha: ".$fecha."</td>
                </tr>
                <tr>
                <td >Id Alumno: ".$idalumno." B</td>
                <td colspan='3'>Nombre: ".$nombre." ".$apellido."</td>
                </tr>
                <tr>
                <td colspan='4'>Recibí la cantidad de $".$cantidad." (MXN) con el concepto de ".$concepto." del alumno(a) ".$nombre." ".$apellido." con domicilio ".$direccion." y teléfono ".$telefono." a razón del tutor ".$tutor."</td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                <td colspan='3' ALIGN='right'>Firma</td>
                <td>Restan: $".$restan." (MXN)</td>
                </tr>
            </tfoot>
            </table>
        </body>
    </html>
    ";

    $dompdf = new Dompdf();
    $dompdf->loadHtml($html);
    $dompdf->setPaper("letter", "portrait");
    $dompdf->render();
    $dompdf->stream('Pago: - '.$nombre." ".$apellido);
    
    $guardar = "INSERT INTO pagos(id_alumno,concepto,cantidad,fecha,hora,nombres,apellidos,direccion,telefono,tutor,pendiente) VALUES (".$idalumno.",'".$concepto."','".$cantidad."','".$fecha."','','".$nombre."','".$apellido."','".$direccion."','".$telefono."','".$tutor."','".$restan."')";
    if (mysqli_query($conn, $guardar)) {
        echo ($guardar);     
    }

?>