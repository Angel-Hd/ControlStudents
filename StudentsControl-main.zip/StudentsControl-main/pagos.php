<!DOCTYPE html>
<html lang="en">
    <head>  
    <meta htto-equiv="Content-Type" content="text/html" charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagos</title>
    <link href="https://fonts.googleapis.com/css2?family=Bitter:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <!--Navrbar-->
        <nav class="navbar navbar-expand-sm navbar-dark bg-dark" id="navbar">
            <div class="container-fluid">
                <a class="navbar-brand" href="http://localhost/Control/menu.php">
                    <img src="img/logo3.png" alt="" width="200">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="http://localhost/Control/menu.php">Alumnos</a></li>
                        <li class="nav-item"><a class="nav-link" href="http://localhost/Control/update.php">Registro</a></li>
                        <li class="nav-item"><a class="nav-link" href="http://localhost/Control/consulta.php">Consulta</a></li>
                        <li class="nav-item"><a class="nav-link" href="http://localhost/Control/pagos.php">Pagos</a></li>
                        <li class="nav-item"><a class="nav-link" href="http://localhost/Control/">Sign out</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!--Carrousel-->
        <h2></h2>
        <div class="col-md-12 ml-md-auto">
            <h2>Pagos</h2>
            <p>Registros actuales a: <?php  echo(date("j")."/".date("F")."/".date("Y")); ?></p>   
        </div>

        <!--Tabla-->
        <div class="col-md-6 ml-md-12">
                <div class="form-group">
                    <label for="items">Alumnos en orden alfabetico por apellidos</label>
                    <select class="form-control" id="items">        
                    <?php 
                        include('conn.php');
                        $ver=0;
                        $consulta = "SELECT * FROM registro ORDER by apellidos";
                        $resultado = mysqli_query( $conn, $consulta );
                        while ($columna = mysqli_fetch_array( $resultado ))
                        {
                            echo "<option value=".$columna[0].">#".$columna[0]." - ".$columna[2]." ".$columna[1]."</option>";
                        }
                        mysqli_close($resultado);
                    ?>
                    </select>
                </div>
        </div>
        <!--php pasar-->
        <!--Form-->
        <div class="col-md-12 ml-md-auto">
            <form class="col-12" action="pdf.php" method="POST">
                <div class="form-group">
                    <label for="id">#</label>
                    <input type="text" class="form-control" placeholder="Numero # de alumno" name=id>
                </div>
                <div class="form-group">
                    <label for="concepto">Concepto</label>
                    <input type="text" class="form-control" placeholder="Pago referente a..." name=concepto value="Curso de apoyo para el exámen a preparatoria">
                </div>
                <div class="form-group">
                    <label for="cantidad">Cantidad</label>
                    <input type="text" class="form-control" placeholder="Cantidad a cobrar ($00.00MXN)" name=cantidad>
                </div>
                <div class="form-group">
                    <label for="restan">Restan</label>
                    <input type="text" class="form-control" placeholder="Cantidad pendiente ($00.00MXN)" name=restan>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
        <!--redireccion-->
        <a href="http://localhost/Control/pruebapdf.php">ver pdf prueba</a>
        <!--script-->    
        <script src="js/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
    </body>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script  src="js/index.js"></script>
</html>