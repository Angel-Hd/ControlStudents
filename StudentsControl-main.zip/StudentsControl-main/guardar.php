<?php 
    include('conn.php');
    $sql = "INSERT INTO registro(nombres,apellidos,telefono,direccion,email,tutor)VALUES("."'".$_POST['nombre']."'".","."'".$_POST['apellido']."'".",".$_POST['telefono'].","."'".$_POST['direccion']."'".","."'".$_POST['email']."'".","."'".$_POST['tutor']."'".")";
    if (mysqli_query($conn, $sql)) {
        echo ($sql);
        header("Location: http://localhost/Control/menu.php");       
    }
?>