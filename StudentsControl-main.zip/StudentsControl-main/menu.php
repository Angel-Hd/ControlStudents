<!DOCTYPE html>
<html lang="en">
    <head>  
    <meta htto-equiv="Content-Type" content="text/html" charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registros</title>
    <link href="https://fonts.googleapis.com/css2?family=Bitter:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="css/main.css">
    </head>
    <body>
        <!--Navrbar-->
        <nav class="navbar navbar-expand-sm navbar-dark bg-dark" id="navbar">
            <div class="container-fluid">
            <a class="navbar-brand" href="http://localhost/Control/menu.php">
                    <img src="img/logo3.png" alt="" width="200">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="http://localhost/Control/menu.php">Alumnos</a></li>
                        <li class="nav-item"><a class="nav-link" href="http://localhost/Control/update.php">Registro</a></li>
                        <li class="nav-item"><a class="nav-link" href="http://localhost/Control/consulta.php">Consulta</a></li>
                        <li class="nav-item"><a class="nav-link" href="http://localhost/Control/pagos.php">Pagos</a></li>
                        <li class="nav-item"><a class="nav-link" href="http://localhost/Control/">Sign out</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!--Carrousel-->
        <h2></h2>
        <div class="col-md-12 ml-md-auto">
            <h2>Alumnos Registrados</h2>
            <p>Registros actuales a: <?php  echo(date("j")."/".date("F")."/".date("Y")); ?></p>   
        </div>
        <div class="col-md-12 ml-md-auto">
            <div class="class=classWithPad">         
                <table class="table">
                    <thead class="thead-dark">
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Apellidos</th>
                        <th scope="col">Telefono</th>
                        <th scope="col">Dirección</th>
                        <th scope="col">Correo</th>
                        <th scope="col">Tutor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            include('conn.php');
                            $ver=0;
                            $consulta = "SELECT * FROM registro";
                            $resultado = mysqli_query( $conn, $consulta );
                            while ($columna = mysqli_fetch_array( $resultado ))
                            {
                                echo"<tr>";
                                echo"<th scope='row'>".$columna['id']."</th>";
                                echo"<td>".utf8_decode($columna['nombres'])."</td>";
                                echo"<td>".$columna['apellidos']."</td>";
                                echo"<td>".$columna['telefono']."</td>";
                                echo"<td>".$columna['direccion']."</td>";
                                echo"<td>".$columna['email']."</td>";
                                echo"<td>".$columna['tutor']."</td>";
                                echo"</tr>";
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!--script-->    
        <script src="js/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>
    </body>
</html>
